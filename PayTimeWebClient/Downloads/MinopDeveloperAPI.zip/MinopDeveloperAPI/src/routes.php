<?php

use Slim\Http\Request;
use Slim\Http\Response;

// Routes

$app->get('/[{name}]', function (Request $request, Response $response, array $args) {
    // Sample log message
    $this->logger->info("Slim-Skeleton '/' route");

    // Render index view
    return $this->renderer->render($response, 'index.phtml', $args);
}); 

$app->post('/api/sayhello', function (Request $request, Response $response) {
     $data = $request->getParsedBody();

     $sayhelloData = [];   
     $sayhelloData['dvcSrNo'] = filter_var($data['dvcSrNo'], FILTER_SANITIZE_STRING);
     $sayhelloData['dvcTime'] = filter_var($data['dvcTime'], FILTER_SANITIZE_STRING);
     $this->logger->info("API SayHello call received with data  dvcSrNo : " . $sayhelloData['dvcSrNo'] . " and dvcTime : " .  $sayhelloData['dvcTime']  );
     $responseMessage['status'] = 1; // 1 for success and 0 for error
     header("Content-Type: application/json");
     header('Access-Control-Allow-Origin', '*');
    $response->getBody()->write(json_encode($responseMessage));
    return $response;
}); 

$app->post('/api/transaction', function (Request $request, Response $response) {
     $data = $request->getParsedBody();
     
     $transactionData = $data['trans'];
     $responseMessage["transStatus"] = array(); 
     
     
     $i = 1;
     foreach($transactionData as $transaction ){
         $reponseTrans = [];
             $logMessage = "API Transaction call received with following transaction data \n";
             $logMessage .= "txnId : " .filter_var($transaction["txnId"], FILTER_SANITIZE_STRING). ", " ; 
             $logMessage .= "dvcId : " .filter_var($transaction["dvcId"], FILTER_SANITIZE_STRING) . ", ";
             $logMessage .= "dvcIP : " .filter_var($transaction["dvcIP"], FILTER_SANITIZE_STRING) .  ", ";
             $logMessage .= "punchId : " .filter_var($transaction["punchId"], FILTER_SANITIZE_STRING) . ", "; 
             $logMessage .= "txnDateTime : " .filter_var($transaction["txnDateTime"], FILTER_SANITIZE_STRING) . ", "; 
             $logMessage .= "mode : " .filter_var($transaction["mode"], FILTER_SANITIZE_STRING) . ", " ;
             $this->logger->info($logMessage);
          $reponseTrans["txnId"] = $transaction["txnId"];
          $reponseTrans["status"] = 1;
          //array_push($responseMessage, $reponseTrans);
//          $responseMessage["transStatus"][] = '{"txnId":'.$transaction["txnId"].' ,"status":1}';
          $responseMessage["transStatus"][] = $reponseTrans;
      
     }
     
 
     header("Content-Type: application/json");
    $response->getBody()->write(json_encode($responseMessage));
    return $response;
}); 